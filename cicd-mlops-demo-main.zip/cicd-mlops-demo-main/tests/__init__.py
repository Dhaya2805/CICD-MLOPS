# Avoid ModuleNotFoundError

import sys

sys.path.append("./src")
